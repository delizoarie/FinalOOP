
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
//import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.border.TitledBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;

import com.toedter.calendar.JDateChooser;

import net.proteanit.sql.DbUtils;
import javax.swing.UIManager;

public class AdminPnl extends JPanel {
	private JTextField textFNameEmp;
	private JTextField textMnameEmp;
	private JTextField textLnameEmp;
	private JTextField textEmailEmp;
	private JTextField textPosEmp;
	private JTextField textPhoEmp;
	private JTextField txtEmpID;
	private JTextField addressEmp;
	private JDateChooser empBdate;
	private JPanel panel;
	private JTable table;
	private JTextField textUsername;
	private JPasswordField passEmp;
	private JComboBox comboBoxGenEmp;
	private Connection con = null;
	private PreparedStatement pst = null;
	private ResultSet rs = null;
	
	/**
	 * Create the panel.
	 */
	public AdminPnl() {
		empBdate = new JDateChooser();
		table = new JTable();
		table.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				int i = table.getSelectedRow();
				TableModel model = table.getModel();
				txtEmpID.setText(model.getValueAt(i, 0).toString());
				textFNameEmp.setText(model.getValueAt(i, 1).toString());
				textMnameEmp.setText(model.getValueAt(i, 2).toString());
				textLnameEmp.setText(model.getValueAt(i, 3).toString());
				
				String gender1 = model.getValueAt(i, 4).toString();
					switch(gender1) {
					case "Male":
						comboBoxGenEmp.setSelectedIndex(0);
						break;
					case "Female":
						comboBoxGenEmp.setSelectedIndex(1);
						break;
							
					}
				textPosEmp.setText(model.getValueAt(i, 5).toString());
				textPhoEmp.setText(model.getValueAt(i, 7).toString());
				textEmailEmp.setText(model.getValueAt(i, 8).toString());
				passEmp.setText(model.getValueAt(i, 9).toString());
				addressEmp.setText(model.getValueAt(i, 10).toString());
				textUsername.setText(model.getValueAt(i, 11).toString());
				/*try {
					int srow = table.getSelectedRow();
					Date date = new SimpleDateFormat ("yyyy-MM-dd").parse((String)model.getValueAt(srow, 6));
					empBdate.setDate(date);
				}
				catch(Exception ex) {
					ex.printStackTrace();
					
				}*/
				
			}
		});
		showTableData();
		setBackground(Color.WHITE);
		setBounds(271, 34, 1047, 560);
		setLayout(null);
				
		JLabel lblAdmin = new JLabel("Admin");
		lblAdmin.setFont(new Font("Segoe UI Semibold", Font.BOLD, 20));
		lblAdmin.setBounds(31, 11, 69, 28);
		add(lblAdmin);
		
		;
		
		JPanel panel_1 = new JPanel();
		panel_1.setBackground(new Color(0, 153, 153));
		panel_1.setBorder(new TitledBorder(UIManager.getBorder("TitledBorder.border"), "", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(0, 0, 0)));
		panel_1.setBounds(126, 48, 808, 308);
		add(panel_1);
		panel_1.setLayout(null);
		panel = new JPanel();
		panel.setBounds(10, 11, 788, 286);
		panel_1.add(panel);
		
		
		empBdate.setBounds(635, 32, 125, 30);
		panel.add(empBdate);
		panel.setBackground(Color.WHITE);
		panel.setLayout(null);
		
		JLabel lblEmpFname = new JLabel("First Name");
		lblEmpFname.setFont(new Font("Segoe UI", Font.PLAIN, 13));
		lblEmpFname.setBounds(30, 78, 69, 26);
		panel.add(lblEmpFname);
		
		textFNameEmp = new JTextField();
		textFNameEmp.setBounds(142, 76, 125, 33);
		panel.add(textFNameEmp);
		textFNameEmp.setColumns(10);
		
		JLabel lblEmpMidName = new JLabel("Middle Name");
		lblEmpMidName.setFont(new Font("Segoe UI", Font.PLAIN, 13));
		lblEmpMidName.setBounds(30, 126, 89, 26);
		panel.add(lblEmpMidName);
		
		textMnameEmp = new JTextField();
		
		JLabel lblLastNameEmp = new JLabel("Last Name");
		createlblLnameEmp(lblLastNameEmp);
		
		textLnameEmp = new JTextField();
		
		textEmailEmp = new JTextField();
		
		textPosEmp = new JTextField();
		
		textPhoEmp = new JTextField();
		
		JLabel lblEmpGen = new JLabel("Gender");
		createlblGenEmp(lblEmpGen);
		
		JLabel lblPositionEmp = new JLabel("Position");
		createlblPosEmp(lblPositionEmp);
		
		JLabel lblBirthdateEmp = new JLabel("Birthdate");
		createlblBdateEmp(lblBirthdateEmp);
		
		JLabel lblPhoneNumberEmp = new JLabel("Phone Number");
		createlblNumEmp(lblPhoneNumberEmp);
		
		comboBoxGenEmp = new JComboBox();
		comboBoxGenEmp.setFont(new Font("Segoe UI", Font.PLAIN, 13));
		comboBoxGenEmp.setEditable(true);
		createComboGenEmp(comboBoxGenEmp);
		
		JLabel lblEmailEmp = new JLabel("Email");
		createlblEmailEmp(lblEmailEmp);
		
	
		JButton btnSaveEmp = new JButton("Save");
		createBtnSave(comboBoxGenEmp, btnSaveEmp);
		
		JButton btnUpdateEmp = new JButton("Update");
		btnUpdateEmp.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try {
					con = DriverManager.getConnection("jdbc:mysql://localhost:3306/vanrental?useTimezone=true&serverTimezone=UTC","root","zaza0421");
					String sql = "UPDATE vanrental.employee SET  Employee_FName=?, Employee_MName=? , Employee_LName=?, Employee_Gender=?, Employee_Position=?, Employee_Birthdate=?, Employee_PhoneNum=?, Employee_Email=?, Employee_Password=?, Employee_Address=?, Employee_Username=? where Employee_ID=?";
					pst = con.prepareStatement(sql);
					pst.setString(1, textFNameEmp.getText());
					pst.setString(2,textMnameEmp.getText());
					pst.setString(3, textLnameEmp.getText());
					String gender;
					gender = comboBoxGenEmp.getSelectedItem().toString();
					pst.setString(4, gender);
					pst.setString(5, textPosEmp.getText());
					SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
					String date = sdf.format(empBdate.getDate());
					pst.setString(6, date);
					pst.setInt(7, Integer.parseInt(textPhoEmp.getText()));
					pst.setString(8, textEmailEmp.getText());
					pst.setString(9, passEmp.getText().toString());
					pst.setString(10, addressEmp.getText());
					pst.setString(11, textUsername.getText());
					pst.setInt(12, Integer.parseInt(txtEmpID.getText()));
					
					pst.executeUpdate();
					JOptionPane.showMessageDialog(null, "Updated Successfully");
					showTableData();
					con.close();
				
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
	
			}
		});
		btnUpdateEmp.setFont(new Font("Segoe UI", Font.PLAIN, 13));
		btnUpdateEmp.setBounds(446, 226, 89, 33);
		panel.add(btnUpdateEmp);
		
		JButton btnDeleteEmp = new JButton("Delete");
		btnDeleteEmp.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try {
					con = DriverManager.getConnection("jdbc:mysql://localhost:3306/vanrental?useTimezone=true&serverTimezone=UTC","root","zaza0421");
					String sql = "DELETE from vanrental.employee where Employee_ID=?";
					pst = con.prepareStatement(sql);
					
					pst.setInt(1, Integer.parseInt(txtEmpID.getText()));
					
					pst.executeUpdate();
					JOptionPane.showMessageDialog(null, "Deleted Successfully");
					showTableData();
					con.close();
				
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		});
		btnDeleteEmp.setFont(new Font("Segoe UI", Font.PLAIN, 13));
		btnDeleteEmp.setBounds(557, 226, 89, 33);
		panel.add(btnDeleteEmp);
		
		JLabel lblEmployeeId = new JLabel("Employee ID");
		lblEmployeeId.setFont(new Font("Segoe UI", Font.PLAIN, 13));
		lblEmployeeId.setBounds(30, 39, 89, 23);
		panel.add(lblEmployeeId);
		
		txtEmpID = new JTextField();
		txtEmpID.setColumns(10);
		txtEmpID.setBounds(142, 32, 125, 33);
		panel.add(txtEmpID);
		
		JLabel lblAddressEmp = new JLabel("Address");
		lblAddressEmp.setFont(new Font("Segoe UI", Font.PLAIN, 13));
		lblAddressEmp.setBounds(535, 73, 69, 30);
		panel.add(lblAddressEmp);
		
		addressEmp = new JTextField();
		addressEmp.setColumns(10);
		addressEmp.setBounds(635, 73, 125, 30);
		panel.add(addressEmp);
		
		JLabel lblUsername = new JLabel("Username");
		lblUsername.setFont(new Font("Segoe UI", Font.PLAIN, 13));
		lblUsername.setBounds(294, 36, 69, 26);
		panel.add(lblUsername);
		
		JLabel lblPassword = new JLabel("Password");
		lblPassword.setFont(new Font("Segoe UI", Font.PLAIN, 13));
		lblPassword.setBounds(294, 79, 69, 24);
		panel.add(lblPassword);
		
		textUsername = new JTextField();
		textUsername.setColumns(10);
		textUsername.setBounds(383, 32, 125, 33);
		panel.add(textUsername);
		
		passEmp = new JPasswordField();
		passEmp.setBounds(383, 76, 125, 32);
		panel.add(passEmp);
		createTextMnameEmo();
		createTextLnameEmp();
		createTextEmailEmp();
		createTextPosEmp();
		createTextPhoEmp();
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 367, 1027, 193);
		add(scrollPane);
		
		
		scrollPane.setViewportView(table);
		

	}
	private void createBtnSave(JComboBox comboBoxGenEmp, JButton btnSaveEmp) {
		btnSaveEmp.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					
					con = DriverManager.getConnection("jdbc:mysql://localhost:3306/vanrental?useTimezone=true&serverTimezone=UTC","root","zaza0421"); 
					String sql = "insert into vanrental.employee(Employee_ID, Employee_FName, Employee_MName , Employee_LName, Employee_Gender, Employee_Position, Employee_Birthdate, Employee_PhoneNum, Employee_Email, Employee_Password, Employee_Address, Employee_Username)"
							+"values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
					pst = con.prepareStatement(sql);
					pst.setInt(1, Integer.parseInt(txtEmpID.getText()));
					pst.setString(2, textFNameEmp.getText());
					pst.setString(3,textMnameEmp.getText());
					pst.setString(4, textLnameEmp.getText());
					String gender;
					gender = comboBoxGenEmp.getSelectedItem().toString();
					pst.setString(5, gender);
					pst.setString(6, textPosEmp.getText());
					SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
					String date = sdf.format(empBdate.getDate());
					pst.setString(7, date);
					pst.setInt(8, Integer.parseInt(textPhoEmp.getText()));
					pst.setString(9, textEmailEmp.getText());
					pst.setString(10, passEmp.getText().toString());
					pst.setString(11, addressEmp.getText());
					pst.setString(12, textUsername.getText());
					
					
					pst.executeUpdate();
					JOptionPane.showMessageDialog(null, "Insert Successfully");
					showTableData();
					con.close();
				}
				catch(Exception ex) {
					JOptionPane.showMessageDialog(null, "ERROR");
					
				}
				
			}
		});
		btnSaveEmp.setFont(new Font("Segoe UI", Font.PLAIN, 13));
		btnSaveEmp.setBounds(333, 226, 89, 33);
		panel.add(btnSaveEmp);
	}
	private void createlblEmailEmp(JLabel lblEmailEmp) {
		lblEmailEmp.setFont(new Font("Segoe UI", Font.PLAIN, 13));
		lblEmailEmp.setBounds(294, 169, 58, 30);
		panel.add(lblEmailEmp);
	}
	private void createComboGenEmp(JComboBox comboBoxGenEmp) {
		comboBoxGenEmp.setModel(new DefaultComboBoxModel(new String[] {"Male", "Female"}));
		comboBoxGenEmp.setBounds(635, 116, 125, 36);
		panel.add(comboBoxGenEmp);
	}
	private void createlblNumEmp(JLabel lblPhoneNumberEmp) {
		lblPhoneNumberEmp.setFont(new Font("Segoe UI", Font.PLAIN, 13));
		lblPhoneNumberEmp.setBounds(531, 167, 96, 30);
		panel.add(lblPhoneNumberEmp);
	}
	private void createlblBdateEmp(JLabel lblBirthdateEmp) {
		lblBirthdateEmp.setFont(new Font("Segoe UI", Font.PLAIN, 13));
		lblBirthdateEmp.setBounds(535, 36, 69, 26);
		panel.add(lblBirthdateEmp);
	}
	private void createlblPosEmp(JLabel lblPositionEmp) {
		lblPositionEmp.setFont(new Font("Segoe UI", Font.PLAIN, 13));
		lblPositionEmp.setBounds(294, 124, 69, 26);
		panel.add(lblPositionEmp);
	}
	private void createlblGenEmp(JLabel lblEmpGen) {
		lblEmpGen.setFont(new Font("Segoe UI", Font.PLAIN, 13));
		lblEmpGen.setBounds(535, 120, 69, 23);
		panel.add(lblEmpGen);
	}
	private void createTextPhoEmp() {
		textPhoEmp.setColumns(10);
		textPhoEmp.setBounds(635, 164, 125, 33);
		panel.add(textPhoEmp);
		
		JButton button = new JButton("Reset");
		button.setFont(new Font("Segoe UI", Font.PLAIN, 13));
		button.setBounds(671, 226, 89, 33);
		panel.add(button);
	}
	private void createTextPosEmp() {
		textPosEmp.setColumns(10);
		textPosEmp.setBounds(383, 119, 125, 33);
		panel.add(textPosEmp);
	}
	private void createTextEmailEmp() {
		textEmailEmp.setColumns(10);
		textEmailEmp.setBounds(383, 164, 125, 33);
		panel.add(textEmailEmp);
	}
	private void createTextLnameEmp() {
		textLnameEmp.setColumns(10);
		textLnameEmp.setBounds(142, 163, 125, 30);
		panel.add(textLnameEmp);
	}
	private void createlblLnameEmp(JLabel lblLastNameEmp) {
		lblLastNameEmp.setFont(new Font("Segoe UI", Font.PLAIN, 13));
		lblLastNameEmp.setBounds(30, 164, 69, 26);
		panel.add(lblLastNameEmp);
	}
	private void createTextMnameEmo() {
		textMnameEmp.setColumns(10);
		textMnameEmp.setBounds(142, 120, 125, 33);
		panel.add(textMnameEmp);
	}
	public void showTableData() {
		try {
			String sql = "select * from vanrental.employee";
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/vanrental?useTimezone=true&serverTimezone=UTC","root","zaza0421"); 
			pst = con.prepareStatement(sql);
			rs = pst.executeQuery();
			table.setModel(DbUtils.resultSetToTableModel(rs));
		}
	
	catch(Exception ex) {
		ex.printStackTrace();
		
	}
	}
}
