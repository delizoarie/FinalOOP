import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JLayeredPane;

import java.awt.Color;
import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;


public class HomePnl extends JPanel {
	//private JLayeredPane layerPane;
	//private MainPnl mainPnl;

	/**
	 * Create the panel.
	 */
	public HomePnl() {
		//mainPnl = new MainPnl();
		//layerPane = new JLayeredPane();
		
		setBackground(Color.WHITE);
		setBounds(271, 34, 1047, 560);
		setLayout(null);
		
		JLabel lblHome = new JLabel("Home");
		lblHome.setFont(new Font("Segoe UI Semibold", Font.BOLD, 20));
		lblHome.setBounds(23, 11, 68, 24);
		add(lblHome);
		
		JButton reservation = new JButton("");
		reservation.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		reservation.setBackground(new Color(0, 153, 153));
		reservation.setBounds(92, 128, 192, 173);
		add(reservation);
		
		JButton book = new JButton("");
		book.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				/*BookPnl book = new BookPnl();
				mainPnl.switchPanel(book);*/
				
			}
		});
		book.setBackground(new Color(0, 153, 153));
		book.setBounds(312, 128, 192, 173);
		add(book);
		
		JButton admin = new JButton("");
		admin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		admin.setBackground(new Color(0, 153, 153));
		admin.setBounds(533, 128, 192, 173);
		add(admin);
		
		JButton driver = new JButton("");
		driver.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		driver.setBackground(new Color(0, 153, 153));
		driver.setBounds(753, 128, 192, 173);
		add(driver);
		
		JButton repair = new JButton("");
		repair.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			}
		});
		repair.setBackground(new Color(0, 153, 153));
		repair.setBounds(187, 339, 192, 173);
		add(repair);
		
		JButton payment = new JButton("");
		payment.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		payment.setBackground(new Color(0, 153, 153));
		payment.setBounds(429, 339, 192, 173);
		add(payment);
		
		JButton maintenance = new JButton("");
		maintenance.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		maintenance.setBackground(new Color(0, 153, 153));
		maintenance.setBounds(658, 339, 192, 173);
		add(maintenance);
		
		

	}
}
