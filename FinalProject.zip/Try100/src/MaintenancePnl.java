import java.awt.Color;

import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.JScrollPane;
import javax.swing.table.DefaultTableModel;

import net.proteanit.sql.DbUtils;

import java.awt.Font;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class MaintenancePnl extends JPanel {
	private JTable table;
	private Connection con = null;
	private PreparedStatement pst = null;
	private ResultSet rs = null;
	/**
	 * Create the panel.
	 */
	public MaintenancePnl() {
		setBackground(Color.WHITE);
		setBounds(271, 34, 1047, 560);
		setLayout(null);
		
		JLabel lblHome = new JLabel("Maintenace");
		lblHome.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblHome.setBounds(10, 33, 102, 27);
		add(lblHome);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 82, 1027, 392);
		add(scrollPane);
		
		table = new JTable();
		table.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
			}
		));
		scrollPane.setViewportView(table);
		showTableData();
	}
	public void showTableData() {
		try {
			String sql = "select * from vanrental.maintenance";
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/vanrental?useTimezone=true&serverTimezone=UTC","root","zaza0421"); 
			pst = con.prepareStatement(sql);
			rs = pst.executeQuery();
			table.setModel(DbUtils.resultSetToTableModel(rs));
		}
	
	catch(Exception ex) {
		ex.printStackTrace();
		
	}
	}
}
