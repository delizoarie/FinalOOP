import java.awt.Color;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import com.toedter.calendar.JDateChooser;

import net.proteanit.sql.DbUtils;

import javax.swing.border.TitledBorder;
import javax.swing.table.TableModel;
import javax.swing.UIManager;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JTable;
import javax.swing.JScrollPane;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class PaymentPnl extends JPanel {
	private JTextField paymentNum;
	private JTextField amount;
	private JDateChooser paymentDate;
	private JScrollPane scrollPane;
	private JTable table;
	private JComboBox comboCategory;
	private JComboBox paymentType;
	private Connection con = null;
	private PreparedStatement pst = null;
	private ResultSet rs = null;
	private JTextField employeeID;

	/**
	 * Create the panel.
	 */
	public PaymentPnl() {

		setBackground(Color.WHITE);
		setBounds(271, 34, 1047, 560);
		setLayout(null);
		
		JLabel lblHome = new JLabel("Payment");
		lblHome.setFont(new Font("Segoe UI Semibold", Font.BOLD, 20));
		lblHome.setBounds(24, 33, 94, 23);
		add(lblHome);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBackground(new Color(0, 153, 153));
		panel_1.setBorder(new TitledBorder(UIManager.getBorder("TitledBorder.border"), "", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(0, 0, 0)));
		panel_1.setBounds(116, 79, 815, 279);
		add(panel_1);
		panel_1.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBounds(10, 11, 793, 255);
		panel_1.add(panel);
		panel.setLayout(null);
		panel.setBackground(Color.WHITE);
		
		JLabel lblPaymentNumber = new JLabel("Payment Number");
		lblPaymentNumber.setFont(new Font("Segoe UI", Font.PLAIN, 13));
		lblPaymentNumber.setBounds(21, 40, 122, 30);
		panel.add(lblPaymentNumber);
		
		paymentNum = new JTextField();
		paymentNum.setColumns(10);
		paymentNum.setBounds(195, 42, 149, 29);
		panel.add(paymentNum);
		
		JLabel lblAmount = new JLabel("Amount");
		lblAmount.setFont(new Font("Segoe UI", Font.PLAIN, 13));
		lblAmount.setBounds(21, 81, 88, 30);
		panel.add(lblAmount);
		
		amount = new JTextField();
		amount.setColumns(10);
		amount.setBounds(195, 83, 149, 29);
		panel.add(amount);
		
		JLabel lblPaymentType = new JLabel("Payment Type");
		lblPaymentType.setFont(new Font("Segoe UI", Font.PLAIN, 13));
		lblPaymentType.setBounds(438, 40, 88, 30);
		panel.add(lblPaymentType);
		
		JLabel lblPaymentDate = new JLabel("Payment Date");
		lblPaymentDate.setFont(new Font("Segoe UI", Font.PLAIN, 13));
		lblPaymentDate.setBounds(438, 81, 105, 30);
		panel.add(lblPaymentDate);
		
		JButton saveBtn = new JButton("Save");
		saveBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try {
					con = DriverManager.getConnection("jdbc:mysql://localhost:3306/vanrental?useTimezone=true&serverTimezone=UTC","root","zaza0421");
					String sql = "INSERT INTO vanrental.payment (Payment_No, Payment_Type, Employee_ID, Payment_Date, Amount, Category)"
							+"VALUES (?,?,?,?,?,?)";
					pst = con.prepareStatement(sql);
					pst.setInt(1, Integer.parseInt(paymentNum.getText()));
					String payType;
					payType = paymentType.getSelectedItem().toString();
					pst.setString(2, payType);
					pst.setInt(3, Integer.parseInt(employeeID.getText()));
					SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
					String date = sdf.format(paymentDate.getDate());
					pst.setString(4, date);
					pst.setString(5, amount.getText());
					String category;
					category = comboCategory.getSelectedItem().toString();
					pst.setString(6, category);
					
					pst.executeUpdate();
					JOptionPane.showMessageDialog(null, "Insert Successfully");
					showTableData();
					con.close();
					
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} 
				
			}
		});
		saveBtn.setFont(new Font("Segoe UI", Font.PLAIN, 13));
		saveBtn.setBounds(375, 197, 89, 33);
		panel.add(saveBtn);
		
		JButton button_1 = new JButton("Update");
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try {
					con = DriverManager.getConnection("jdbc:mysql://localhost:3306/vanrental?useTimezone=true&serverTimezone=UTC","root","zaza0421");
					String sql = "UPDATE vanrental.payment SET Payment_Type=?, Employee_ID=?, Payment_Date=?, Amount=?, Category=? where Payment_No=?";
					pst = con.prepareStatement(sql);

					String payType;
					payType = paymentType.getSelectedItem().toString();
					pst.setString(1, payType);
					pst.setInt(2, Integer.parseInt(employeeID.getText()));
					SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
					String date = sdf.format(paymentDate.getDate());
					pst.setString(3, date);
					pst.setString(4, amount.getText());
					String category;
					category = comboCategory.getSelectedItem().toString();
					pst.setString(5, category);
					pst.setInt(6, Integer.parseInt(paymentNum.getText()));
					pst.executeUpdate();
					JOptionPane.showMessageDialog(null, "Updated Successfully");
					showTableData();
					con.close();
				
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		});
		button_1.setFont(new Font("Segoe UI", Font.PLAIN, 13));
		button_1.setBounds(475, 197, 89, 33);
		panel.add(button_1);
		
		JButton button_2 = new JButton("Delete");
		button_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {try {
				con = DriverManager.getConnection("jdbc:mysql://localhost:3306/vanrental?useTimezone=true&serverTimezone=UTC","root","zaza0421");
				String sql = "DELETE from vanrental.payment where Payment_No=?";
				pst = con.prepareStatement(sql);
				
				pst.setInt(1, Integer.parseInt(paymentNum.getText()));
				
				pst.executeUpdate();
				JOptionPane.showMessageDialog(null, "Deleted Successfully");
				showTableData();
				con.close();
			
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			}
		});
		button_2.setFont(new Font("Segoe UI", Font.PLAIN, 13));
		button_2.setBounds(574, 197, 89, 33);
		panel.add(button_2);
		
		JButton button_3 = new JButton("Reset");
		button_3.setFont(new Font("Segoe UI", Font.PLAIN, 13));
		button_3.setBounds(673, 197, 89, 33);
		panel.add(button_3);
		
		paymentDate = new JDateChooser();
		paymentDate.setBounds(612, 83, 149, 30);
		panel.add(paymentDate);
		
		paymentType = new JComboBox();
		paymentType.setFont(new Font("Segoe UI", Font.PLAIN, 13));
		paymentType.setModel(new DefaultComboBoxModel(new String[] {"Cash", "Mastercard", "Check", "Visa"}));
		paymentType.setBounds(612, 40, 150, 30);
		panel.add(paymentType);
		
		JLabel labelCat = new JLabel("Category");
		labelCat.setFont(new Font("Segoe UI", Font.PLAIN, 13));
		labelCat.setBounds(21, 122, 88, 30);
		panel.add(labelCat);
		
		comboCategory = new JComboBox();
		comboCategory.setFont(new Font("Segoe UI", Font.PLAIN, 13));
		comboCategory.setModel(new DefaultComboBoxModel(new String[] {"Booking", "Reservation", "Repair", "Maintenance"}));
		comboCategory.setBounds(195, 122, 150, 30);
		panel.add(comboCategory);
		
		JLabel TransactionNum = new JLabel("Employee ID");
		TransactionNum.setFont(new Font("Segoe UI", Font.PLAIN, 13));
		TransactionNum.setBounds(438, 122, 126, 30);
		panel.add(TransactionNum);
		
		employeeID = new JTextField();
		employeeID.setColumns(10);
		employeeID.setBounds(613, 124, 149, 29);
		panel.add(employeeID);
		
		scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 392, 1016, 157);
		add(scrollPane);
		
		table = new JTable();
		table.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				int i = table.getSelectedRow();
				TableModel model = table.getModel();
				paymentNum.setText(model.getValueAt(i, 0).toString());
				String payment = model.getValueAt(i, 1).toString();
				switch(payment) {
				case "Cash":
					paymentType.setSelectedIndex(0);
					break;
				case "Mastercard":
					paymentType.setSelectedIndex(1);
					break;
				case "Check":
					paymentType.setSelectedIndex(2);
					break;
				case "Visa":
					paymentType.setSelectedIndex(3);
					break;
				}
				employeeID.setText(model.getValueAt(i, 2).toString());
				amount.setText(model.getValueAt(i, 3).toString());
				String category = model.getValueAt(i, 1).toString();
				switch(category) {
				case "Booking":
					paymentType.setSelectedIndex(0);
					break;
				case "Reservation":
					paymentType.setSelectedIndex(1);
					break;
				case "Repair":
					paymentType.setSelectedIndex(2);
					break;
				case "Maintenance":
					paymentType.setSelectedIndex(3);
					break;
				}
				
			}
		});
		showTableData();
		scrollPane.setViewportView(table);
	}
	public void showTableData() {
		try {
			String sql = "select Payment_No, Payment_Type, Employee_ID, Payment_Date, Amount, Category from vanrental.payment";
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/vanrental?useTimezone=true&serverTimezone=UTC","root","zaza0421"); 
			pst = con.prepareStatement(sql);
			rs = pst.executeQuery();
			table.setModel(DbUtils.resultSetToTableModel(rs));
		}
	
		catch(Exception ex) {
			ex.printStackTrace();
		}
	}
	
}
